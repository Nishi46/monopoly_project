open Property 
open Chance_cc

type board_space = 
| Property of property 

type b = [] 
